# Remember to set the XMLRPCUSER and XMLRPCPASS environment variables
python px_process_params.py --wiki-update

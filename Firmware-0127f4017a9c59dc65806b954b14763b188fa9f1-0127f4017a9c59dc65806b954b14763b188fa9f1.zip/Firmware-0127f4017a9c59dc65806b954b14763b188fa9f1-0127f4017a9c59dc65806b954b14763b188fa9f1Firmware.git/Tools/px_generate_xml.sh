#!/bin/sh
python px_process_params.py --xml

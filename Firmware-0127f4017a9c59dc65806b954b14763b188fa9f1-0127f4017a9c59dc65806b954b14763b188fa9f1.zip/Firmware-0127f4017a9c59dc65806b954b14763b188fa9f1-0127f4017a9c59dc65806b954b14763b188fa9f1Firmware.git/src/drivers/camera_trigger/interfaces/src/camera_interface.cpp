#include "camera_interface.h"

/**
 * @file camera_interface.cpp
 *
 */

CameraInterface::CameraInterface()
{
}

CameraInterface::~CameraInterface()
{
}

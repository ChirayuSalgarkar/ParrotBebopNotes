This directory contains header files unique to the PX4IO board.

This directory contains header files unique to the Linux user-mode platform.
